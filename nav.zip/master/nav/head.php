 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <!-- Bootstrap CSS -->
 <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
 <link rel="stylesheet" href="assets/vendor/fonts/circular-std/style.css" >
 <link rel="stylesheet" href="assets/libs/css/style.css">
 <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">

 <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
 <!-- <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css"> -->

 <link rel="stylesheet" type="text/css" href="assets/sweetalert.css">
 <link rel="stylesheet" type="text/css" href="assets/vanila_del_prompt.css">

 <link rel="icon" type="image/png" href="../images/lojas.jpg">
 <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/dataTables.bootstrap4.css">
 <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/buttons.bootstrap4.css">
 <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/select.bootstrap4.css">
 <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/fixedHeader.bootstrap4.css">

 <script  src="assets/sweetalert.min.js"></script>
 <script src="assets/vanila_del_prompt.js"></script>
 <script src="assets/vendor/ckeditor/ckeditor.js"></script>