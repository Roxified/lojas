 <div class="footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
        Copyright © <?php echo date('Y');  ?>. All rights reserved. <a href="https://lojas.org.ng">LOJAS</a>.
      </div>
      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
        <div class="text-md-right footer-links d-none d-sm-block">
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>